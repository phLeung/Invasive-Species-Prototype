<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Password Changed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width-device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="../../style.css" rel="stylesheet" type="text/css">
</head>
<body>
  <?php include 'headerSubSub.php';?>
  <div style="text-align:center; margin:40px" class="Changed">
     <h2 style="font-family:Coustard">Password has been changed</h2>
     <p style="font-family: 'Abel', serif;">You have successfully set your new password</p>
   </div>
</body>
</html>     
