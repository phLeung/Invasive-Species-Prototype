<!DOCTYPE html>
<html lang="en">
<head>
    <title>The Invaders: Cards</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>

    <!-- Header -->
    <?php include 'header.php';?>
       

    <!-- Content -->
    <div class = "card">
        <img src="images/exampleCards.jpg" alt="4 Card Types" style="width: 700px; height: 500px">
    </div>

</body>
</html>